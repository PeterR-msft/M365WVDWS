# Description

The xADDomainDefaultPasswordPolicy DSC resource will manage an Active Directory domain's default password policy.
